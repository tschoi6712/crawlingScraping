from django.contrib import admin
from book.models import Publisher
admin.site.register(Publisher)