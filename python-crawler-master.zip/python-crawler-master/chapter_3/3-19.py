def sum(a, b=0):
    result = a + b
    print(result)
    return result
    
result = sum(2,3) # 5가 출력되며, 동시에 5가 반환됩니다.