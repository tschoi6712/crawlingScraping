for x in range(5):
    print(x) # 0부터 4까지 차례대로 출력