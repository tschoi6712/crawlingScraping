a = 5
b = 10
print(a + b)